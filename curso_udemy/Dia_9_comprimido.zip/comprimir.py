import zipfile 
import shutil 
mi_zip = zipfile.ZipFile("archivo_comprimido.zip","w")
mi_zip.write("Dia_9\\mi_archivo.txt")

mi_zip.close()

carpeta_origen = "C:\\Users\\EDMG0\\Documents\\Proyectos_python\\curso_udemy\\Dia_9"

archivo_destino = "Dia_9_comprimido"

shutil.make_archive(archivo_destino, "zip", carpeta_origen)
