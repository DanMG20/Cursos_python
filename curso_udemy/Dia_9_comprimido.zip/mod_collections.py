# Practica 1 

from collections import *
lista = [1, 2, 3, 6, 7, 1, 2, 4, 5, 5, 5, 5, 3, 2, 6, 7]

contador = Counter(lista)


#PRACTICA 2 

mi_diccionario= defaultdict(lambda: "Valor no hallado")

mi_diccionario["Edad"] = 44 

mi_diccionario["Calabaza"] 

print(mi_diccionario)


#practica 3  

lista_deque = deque(["Londres", "Berlin", "París", "Madrid", "Roma", "Moscú"])


