#practica 1 
#modulo time 
#modulo timeit 

