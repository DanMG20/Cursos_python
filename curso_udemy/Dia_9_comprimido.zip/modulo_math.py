import math 


#practica 1 

resultado = math.log10(25)
#practica 2

resultado = math.sqrt(math.pi)
#practica 3 
resultado = math.factorial(7)

